
#Jordan Hernandez-Alamche
#CSci 161 L03
#Assignment MIDTERM


'''
Write a program that imports the math module. Prompt the user to enter an integer value, the number of degrees in an angular measure. Use
functions from the math module to convert the degrees into radians, and to calculate the cosine of the resulting radians. Print out the 
degrees, radians, and the cosine value.
'''
import math

user_entry = int(input('Enter degrees in an angular measure: '))
#FIXME
#fix math behind entries
print(math.radians(user_entry))
print(math.cos(user_entry))
print(math.degrees(user_entry))

