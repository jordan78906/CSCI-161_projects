
#Jordan Hernandez-Alamche
#CSci 161 L03
#Assignment MIDTERM


'''
Write a program that creates an empty list, and then has a for loop that asks the user to put in 5 names, 
adding each name to the list as the program goes(the names are single words). When this is done, sort the 
list alphabetically and print it out.
'''
new_list = []
count = 0

for i in range(0,5):
    user_entry = input('Enter a name: ')
    new_list.append(user_entry)
    count += 1

print(sorted(new_list))
