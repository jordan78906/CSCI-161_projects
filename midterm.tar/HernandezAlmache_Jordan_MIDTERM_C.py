
#Jordan Hernandez-Alamche
#CSci 161 L03
#Assignment MIDTERM


'''
Write a program with a user-defined function called 'clamp', which takes as an input a single integer. If the input number is negative, have the function return zero. if value is positive and greater than 255, have the function return zero. If the value is between 0 and 255, have the function return unaltered. Write a main program section that prompts the user to enter a number, recast it to an integer, and call s the clamp function. The program should then print out the value returned by the function call.
'''
def clamp(int_user_entry):
    if int_user_entry == range(0,256):
        return int_user_entry
    elif int_user_entry < 0:
        int_user_entry = 0
    elif int_user_entry > 255:
        int_user_entry = 0

    return int_user_entry


user_entry = input('Enter an integer: ')
int_user_entry =int(user_entry)
new_info = clamp(int_user_entry)
print(new_info)


