
#Jordan Hernandez-Alamche
#CSci 161 L03
#Assignment MIDTERM


'''
Write a program with a class definition 'Aircraft'. The construct should take in arguments for tail_number, latitude, longitude, altitude, heading, and speed.
These should be stored in a dictionary. the keyis the parameter name(e.g. 'tail_number'), and the value will be argument passed to the constructor(e.g.'N51123ND').
Also have a method definition in the class called 'print_plane', which prints out all of these values for a given instantiation of the class. In the main portion 
of the program, have an initially-empty list called 'airplanes'. Have the user enter the arguments listed above, call the constructor, and add the new object to the list.
Do this three ties, so that there will be a list with three instantiations of the aircraft class in it. Finally, use a 'for' loop to iterate over the list, calling the
print_plane method from each object in the list.
'''

class Aircraft:
    dict_airplane = {'tail_number' : 0, 'latitude': 0, 'longitude': 0, 'altitude': 0, 'heading': 0, 'speed': 0}

        def method(print_plane):
            for i in dict_airplane.values():
                print(i)


airplanes = []


print('Hello, World!')
