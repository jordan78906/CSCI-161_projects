
#Jordan Hernandez-Alamche
#CSci 161 L03
#Assignment MIDTERM


'''
Write a prog that uses the input comm to have the user enter an int num. Recast the input str to an int and a float point number.
print the number as a str, as an int, and as a float. Use the type() function and the id() function to print out the type and id of each of the items printed.
type() - gives you and obj.
id() - gives its location in memory
'''

user_entry = input('Enter a number: ')

int_entry = int(user_entry)
float_entry = float(user_entry)


print('{x:<8}type:'.format(x = user_entry),type(user_entry),'{y:<8}id:'.format(y = ''),id(user_entry))
print('{x:<8}type:'.format(x = int_entry),type(int_entry),'{y:<8}id:'.format(y = ''),id(int_entry))
print('{x:<8}type:'.format(x = float_entry),type(float_entry),'{y:>6}id:'.format(y = ''),id(float_entry))

