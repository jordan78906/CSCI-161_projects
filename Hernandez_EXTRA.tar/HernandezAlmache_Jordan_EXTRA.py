
#Jordan Hernandez-Alamche
#CSci 161 L03
#Assignment Extra Credit

#all possible combinations of word
def scramble(r_letters,s_letters):
    if len(r_letters) == 0:
        print(s_letters)

    else:
        for j in range(len(r_letters)):
            scram_letters = r_letters[j]
            remaining_letters = r_letters[:j] + r_letters[j + 1:]
            scramble(remaining_letters, s_letters + scram_letters)



#read a list of words from a file
with open('input.txt','r') as scarmbled_input:
    scarmbled_words = []
    for i in scarmbled_input:
        i = i.rstrip()
        i = i.lower()
        scarmbled_words.append(i)
print(scarmbled_words)

#reference words with dictionary /usr/chare/dict/american-english
#un-CAP words from dictionary
with open('american-english.txt','r') as american_english_input:
    american_english_dict = []
    for k in american_english_input:
        k = k.rstrip()
        k = k.lower()
        american_english_dict.append(k)
print(american_english_dict)

#call per word
for word in scarmbled_words:
    scramble(word,'')

    if word == 'cat':
        print('{} Found'.format(word))
    else:
        print('{} Not Found'.format(word))

'''


print('\nJumbled word: Solved Word')
print('=========================')
print(scarmbled_words[0])
#print('{}: act cat'.format(scarmbled_words[0])
#
#
#oobarf: no word found
'''
