
#Jordan Hernandez-Alamche
#CSci 161 L03
#FINAL 3

#Build a program to find the first non-repeating integer in a list. The program will have an
#in-built list as [9,2,4,3,2,6,6,9]
#Hint: you can use dict to keep a count of the repetitions of int
#output - 4


counts = dict()
list_a = ['9','2','4','3','2','6','6','9']
print('In-built list:')
print (list_a) 

for list_b in list_a:
    if list_b not in counts:
        counts[list_b] = 1
    else:
        counts[list_b] = counts[list_b] + 1

#print(counts)

smallcount = None
for a,b in counts.items():
    if smallcount is None or b < smallcount:
        key = a
        smallcount = b
print('Output: {}'.format(key))

