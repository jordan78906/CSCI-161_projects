
#Jordan Hernandez-Alamche
#CSci 161 L03
#FINAL 4

#Build a program to reverse the linked list if the given linked list is a palindrome.
#A list is said to be a palindrome if the reverse of the list is the same as the original list.
#a)Given the head of a singly linked list, reverse the list, and return the reversed list.
#b)Given the head of a singly linked list, return true if it is a palindrome.
'''
input:
list_a = [1,2,2,1]
Output:
reverse = [1,2,2,1]
palindrome = true
'''
class Node:
    def __init__(self, data = None):
        self.data = data
        self.next = None

class Linked_List:
    def  __init__(self):
        self.head = Node()

    def append(self, data):
        new_node = Node(data)
        cur = self.head
        while cur.next != None:
            cur = cur.next
        cur.next = new_node

    def display(self):
        elems = []
        cur_node = self.head
        while cur_node.next != None:
            cur_node = cur_node.next
            elems.append(cur_node.data)
        print (elems)
"""
    def ListTraverseReverse(self, init_list):
        ListTraverseReverseRecursive(init_list -> head)
        

    def ListTraverseReverseRecursive(self, node):
            if(node is not null):
                ListTraverseReverseRecursive(node -> next)
                Visit node
"""           
List_A = Linked_List() 
List_A.display ()       
List_A.append (1)
List_A.append (2)
List_A.append (2)
List_A.append (1)
List_A.display ()
#List_A.ListTraverseReverse ()     

