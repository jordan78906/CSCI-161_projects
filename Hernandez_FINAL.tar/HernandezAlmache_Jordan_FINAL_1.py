
#Jordan Hernandez-Alamche
#CSci 161 L03
#FINAL 1

#A website req the user to input username/password to register. 
#Write a program to check the validity of password input by users.
#1) At least 1 lowercase letter[a-z]
#2) At least 1 number[0-9]
#3) At least 1 uppercase letter[A-Z]
#4) At least 1 character from [$#@]
#5) Minimum length of transaction password: 6
#6) Maximum length of transaction password: 12
#accept a sequence of , seperated passwords and check each with above criteria

def PasswordValidity(password):
    lowercase_letters = 'abcdefghijklmnopqrstuvwxyz'
    numbers = '0123456789'
    uppercase_letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    special = '$#@'
    total = None
    x = y = z = p = 0

    if len(password) >= 6 and len(password) <= 12:
        for i in range(len(password)):
            if password[i] in lowercase_letters:
                x = 1
            elif password[i] in numbers:
                y = 1
            elif password[i] in uppercase_letters:
                z = 1
            elif password[i] in special:
                p = 1
        total = x + y + z + p
        if total == 4:
            print('Valid Entry: {}'.format(password))
        else:
            print('Invalid Entry')
    else:
        print('Invalid Entry')

pw_entries = input(str('Enter a password:'))
#pw_entries = 'ABd1234@1,aF1#,2w3E*,2We3345'
passwords = pw_entries.split(',')
print('Passwords Entered:',passwords)
for password in passwords:
    PasswordValidity (password)




