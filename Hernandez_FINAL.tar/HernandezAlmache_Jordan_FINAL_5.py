
#Jordan Hernandez-Alamche
#CSci 161 L03
#FINAL 5

#Build a program to order a pizza from a list of available pizzas and toppings. The pizzza and
#toppings will be pre-defines and the user can only select one pizza type and one topping
#Hint: You can use classes and methods for this program
#
'''
class Pizza:
    def __init__(self):
        self.pizza_name = ''
        self.pizza_top = ''
        self.amount = 0.0 
    def PizzaChoise(self,pizza_choise):
        if 
class PizzaToppings(Pizza,topping_choise):
    def __init__(self):
        Pizza.__init__(self)
        self.
'''

available_pizzas = ['Margarita','Hawaiian','4cheese','Vegetarian','Pepperoni']
available_toppings = ['mushroom','onions','green pepper','extra cheese']
pizza_prices = {'Margarita':5,'Hawaiian':7,'4cheese':6,'Vegetarian':6.5,'Pepperoni':9}
topping_prices = {'mushroom':1,'onions':2,'green pepper':3,'extra cheese':4}


command = None
while command != 'n':
    command = input(str('Welcome! Would you like to order? (y/n):'))
    if command == 'y':
        print('Hi, welcome to our text based pizza ordering')
        print('Available Pizzas')
        print('----------------')
            #print('Margarita, Hawaiian, 4cheese, Vegetarian, Pepperoni')
        for a in available_pizzas:
            print (a)
        print('\nAvailable Toppings')
        print('------------------')
        for b in available_toppings:
            print (b)
        pizza_choise =input(str('\nPlease choose a pizza:'))
        topping_choise =input(str('Please choose a topping:'))
        for a in available_pizzas:
            
            if pizza_choise not in pizza_prices:
                print('The selected pizza is not available')
                break
        for b in available_toppings:
            
            if topping_choise not in topping_prices:
                print('The selected topping is not available')
                break
        pizza_total = pizza_prices[pizza_choise] + topping_prices[topping_choise]

        print('\nFinal order:')
        command = input(str('Would you like to change your order?(y/n):'))
        if command != 'y':
            print('{} for ${}'.format(pizza_choise,pizza_prices[pizza_choise]))
            print('{} for ${}'.format(topping_choise,topping_prices[topping_choise]))
            print('---------------------')
            print ('Total: ${}'.format(pizza_total))
        else:
            continue



